import os
from flask import Flask,render_template,request,jsonify,redirect,session
from flask_sqlalchemy import SQLAlchemy
import bcrypt

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///prod.db'

db = SQLAlchemy(app)
app.secret_key = 'secret_key'


# User/Admin database
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(200), unique=True)
    password = db.Column(db.String(100))
    
    def __init__(self,email,password,name) -> None:
        self.name = name
        self.email=email
        self.password=bcrypt.hashpw(password.encode('utf-8'),bcrypt.gensalt()).decode('utf-8')
        
    def check_password(self,password):
        return bcrypt.hashpw(password.encode('utf-8'),self.password.encode('utf-8'))



#product information database
class ProductsInfo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    Title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.String(200), nullable=False)
    price = db.Column(db.Integer)
    
    def __repr__(self) -> str:
        return f"{self.id} - {self.Title}"
    
# Route to register
@app.route('/register',methods=['GET','POST'])
def register():
    if request.method == 'POST':
        name=request.form['name']
        email=request.form['email']
        password=request.form['password']
        
        new_user = User(name=name,email=email,password=password)
        db.session.add(new_user)
        db.session.commit()
        return redirect('login')
            
    return render_template('register.html')

# Route to login
@app.route('/login',methods=['GET','POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        user = User.query.filter_by(email=email).first()
        
        if user and user.check_password(password):
            session['name'] = user.name
            session['email'] = user.email
            session['password'] = user.password
            return redirect('/allpro')
        else:
            return render_template('login.html',error='Invalid user')
    return render_template('login.html')

# Route to create a new product
@app.route('/',methods=['GET','POST'])
def hello_world():
    if request.method == "POST":
        title = request.form["title"]
        desc = request.form['description']
        pri = request.form['price']
        pr = ProductsInfo(Title=title,description =desc,price=pri )
        db.session.add(pr)
        db.session.commit()
        
    return render_template('index.html')


# Route to get the all product
@app.route('/allpro')
def all_product():
    allp = ProductsInfo.query.all()
    return render_template('productss.html',allp = allp)

# Route to delete product by id
@app.route("/delete/<int:id>")
def del_product(id):
    d_pr = ProductsInfo.query.filter_by(id=id).first()
    db.session.delete(d_pr)
    db.session.commit()
    return redirect('/allpro')

# Route to update product by id
@app.route("/update/<int:id>",methods=['GET','POST'])
def update_product(id):
    if request.method == 'POST':
        title = request.form['utitle']
        desc = request.form['udescription']
        price= request.form['uprice']
        up_pr = ProductsInfo.query.filter_by(id=id).first()
        up_pr.Title = title
        up_pr.description = desc
        up_pr.price = price
        
        db.session.add(up_pr)
        db.session.commit()
        return redirect('/allpro')
    up_pr = ProductsInfo.query.filter_by(id=id).first()
    print(up_pr.Title)
    
    return render_template('update-product.html',up_pr=up_pr)



if __name__ == "__main__":
    with app.app_context():
        db.create_all()
        app.run(debug=False)